<?php $__env->startSection('title', 'Welcome'); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <main role="main" class="inner cover mt-5 pt-5">
                <h1 class="cover-heading">Learning Management System</h1>
                <p class="lead">
                
                <p class="lead">
                <?php if(auth()->guard()->check()): ?>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-lg btn-secondary" type="submit">Logout <i class="fa-solid fa-power-off"></i></button>
                    </form>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="btn btn-lg btn-secondary">Login <i class="fa-solid fa-right-to-bracket"></i></a>
                <?php endif; ?>
                
                </p>
            </main>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kirtj\project1\resources\views/welcome.blade.php ENDPATH**/ ?>