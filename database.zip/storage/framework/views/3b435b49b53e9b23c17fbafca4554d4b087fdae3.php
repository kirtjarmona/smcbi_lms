<!DOCTYPE html>
<html>

<head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <link href="<?php echo e(asset('css/all.min.css')); ?>" rel="stylesheet">
    <style>
    .background-cover {
        background-image: url(<?php echo e(asset('images/4907157.jpg')); ?>);
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
    }
    </style>
</head>

<body class="d-flex h-100 text-center text-bg-dark background-cover">
    <?php if(Session::has('success')): ?>
        <div class="modal fade" id="successModal" tabindex="-1" role="dialog" aria-labelledby="successModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-body text-center">
                        <div class="alert alert-success fade show" role="alert">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script>
            $(document).ready(function() {
                $('#successModal').modal('show');
                setTimeout(function() {
                    $('#successModal').modal('hide');
                }, 2000);
            });
        </script>
    <?php endif; ?>


    <?php if(auth()->guard()->check()): ?>
        
    <?php else: ?>
    <?php endif; ?>


    <div class="container background-cover">

        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>

</html>
<?php /**PATH C:\Users\kirtj\project1\resources\views/layouts/app.blade.php ENDPATH**/ ?>