<div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm">
    <a class="my-0 mr-md-auto font-weight-normal btn btn-none" href="/"><h3 class="my-0 mr-md-auto font-weight-normal"><i class="fa-solid fa-school"></i> SMCBI</h3></a>

    <?php if(auth()->guard()->check()): ?>
        <a class="btn btn-outline-primary" href="<?php echo e(url('/dashboard')); ?>">Dashboard</a>
    <?php else: ?>
        <a class="btn btn-outline-primary" href="<?php echo e(route('login')); ?>">Login</a>
    <?php endif; ?>

    <nav class="my-2 my-md-0 ml-md-3">
        <?php if(auth()->guard()->check()): ?>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button class="btn btn-none" type="submit">Logout</button>
            </form>
        <?php else: ?>
            <?php if(Route::has('register')): ?>
                <a class="p-2 text-dark" href="<?php echo e(route('register')); ?>">Register</a>
            <?php endif; ?>
        <?php endif; ?>

    </nav>

</div>
<?php /**PATH C:\Users\kirtj\project1\resources\views/layouts/nav.blade.php ENDPATH**/ ?>