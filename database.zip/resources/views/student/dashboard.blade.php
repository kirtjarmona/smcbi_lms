@extends('layouts.app')

@section('title', 'Register')

@section('content')
@include('layouts.nav')
Student Dashboad

@endsection