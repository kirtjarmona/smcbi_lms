@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
    @include('layouts.nav')
    @include('admin.sidebar_nav')
    
@endsection
