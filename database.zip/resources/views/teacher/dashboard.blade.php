@extends('layouts.app')

@section('title', 'Register')

@section('content')
@include('layouts.nav')
Teacher Dashboad

@endsection